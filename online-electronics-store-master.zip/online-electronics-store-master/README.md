# online-electronics-store
it is small ecommerce platform for selling and buying electronics.  
